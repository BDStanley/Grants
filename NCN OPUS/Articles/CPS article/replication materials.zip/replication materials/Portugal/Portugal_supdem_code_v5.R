#### Measuring support for liberal democracy
#### Code for revised draft of paper
#### Portugal
#### Version 5 - February 2023


library(tidyverse)
library(psych)
library(lavaan)
library(car)
library(semTable)
library(psychTools)
library(tth)
library(haven)
library(RColorBrewer)
library(matrixStats)


# read spss file
pt_dat = read_sav("Cronos 6 panel Portugal merged with Round 10.sav")

# examine responses
names(pt_dat)
summary(pt_dat)

# extract sup democ data
sd_dat = pt_dat[, which(colnames(pt_dat)=="FREXP1"):which(colnames(pt_dat)=="EQLAW2")]
sapply(sd_dat, table, useNA="ifany") # check if DKs and NAs are included and how they are coded

# adjust weights
pt_dat$adj_wt = pt_dat$pspwght / mean(pt_dat$pspwght)


## Plot item distributions

# colour palettes (if there are no DK options, delete the last entry of each of these vectors, 
# i.e., delete "#b4b1b1" and "DK")
lik5 = c(brewer.pal(5, "BrBG"))
lik5_labs = c("StrAg", "SomeAg", "Neither", "SomeDis",
              "StrDis")

#  recode missing values as NAs; change "miss" to the missing code
sd_plot = as.data.frame(sapply(sd_dat, function(x) car::recode(x, "99=NA"), simplify = TRUE))

# plot
pdf("supdem_distr_port.pdf", height=8, width=6)
par(mfrow=c(5, 4), mar=c(3, 2, 0.5, 0.5), tcl=-0.2, cex=0.9, las=2, mgp=c(1.8, 0.9, 0))
for(i in 1:length(sd_plot)) {
  barplot(height = table(sd_plot[, names(sd_plot)[i]]) / dim(sd_plot)[1] * 100, names.arg=lik5_labs, 
          axes=FALSE, col=lik5, cex.names=0.7, mgp=c(1, 0.2, 0), ylim=c(0, 80))
  axis(side=2, labels=TRUE, cex.axis=0.7, mgp=c(1, 0.4, 0))
  text(x=1.5, y=75, names(sd_plot)[i], cex=0.8, adj=0)
}
dev.off()


## Recode to orient all items in a pro-democratic direction and DKs as "neither"; 

sd_dat_r = sd_dat
dem_vnam = c("FREXP1", "FRASSC2", "UNISUFF2", "DECELEC2", "FRELECT1", "JUDCNSTR1", "LEGCNSTR2", "EQLAW2")
aut_vnam = c("FREXP2", "FRASSC1", "FRASSC3", "UNISUFF1", "DECELEC1", "FRELECT2", "JUDCNSTR2", "LEGCNSTR1", "EQLAW1")
sd_dat_r[, dem_vnam] = lapply(sd_dat[, dem_vnam], car::Recode, "1=5; 2=4; 3=3; 4=2; 5=1; 99=3; else=NA")
sd_dat_r[, aut_vnam] = lapply(sd_dat[, aut_vnam], car::Recode, "1=1; 2=2; 3=3; 4=4; 5=5; 99=3; else=NA")
pt_dat[, dem_vnam] = sd_dat_r[, dem_vnam]
pt_dat[, aut_vnam] = sd_dat_r[, aut_vnam]


## Reliability and dimensionality

# alpha
sd_cor = cor(sd_dat_r, use="pair")
psych::alpha(sd_cor)
alph_out <- psych::alpha(sd_cor)
write.csv(alph_out[[1]], file="sd_alpha.csv")

# eigenvalues of principal components
eigen(sd_cor)$values
write.csv(eigen(sd_cor)$values, file="sd_eigen.csv")

# 1-factor EFA
psych::fa(sd_dat_r, nfactors=1)
efa1 = psych::fa(sd_dat_r, nfactors=1)
efa_html = tth(fa2latex(efa1))
writeLines(efa_html, "sd_efa1.html")

# ordinal
sd_pcor = polychoric(sd_dat_r)$rho
write.csv(sd_pcor, "sd_pcormat.csv", row.names=TRUE)
psych::fa(sd_pcor, nfactors=1, n.obs=dim(sd_dat)[1])
efa_ord = psych::fa(sd_pcor, nfactors=1, n.obs=dim(sd_dat)[1])
efa_ord_html = tth(fa2latex(efa_ord))
writeLines(efa_ord_html, "sd_efa1_ord.html")


## CFA models

# liberal democracy factor with orthogonal methods factor

cfa_mod_1 = '
SupLD =~ FREXP1 + FREXP2 + FRASSC1 + FRASSC2 + FRASSC3 + UNISUFF1 + UNISUFF2 
          + DECELEC1 + DECELEC2 + FRELECT1 + FRELECT2 + JUDCNSTR1 + JUDCNSTR2 
          + LEGCNSTR1 + LEGCNSTR2 + EQLAW1 + EQLAW2
PosVal =~ FREXP1 + FRASSC2 + UNISUFF2 + DECELEC2 + FRELECT1 + JUDCNSTR1 + LEGCNSTR2 + EQLAW2
'
sd_cfa_1_std = cfa(cfa_mod_1, data=pt_dat, estimator="MLR", orthogonal=TRUE, std.lv=TRUE, 
                   sampling.weights="adj_wt")
semTable(sd_cfa_1_std, paramSets = c("fits", "loadings", "latentvariances", "latentcovariances"),
         fits=c("chisq", "cfi", "rmsea", "srmr"), columns=c("est", "se", "p"),
         type="html", file="cfa_1fac_std_table_w.html")
sd_cfa_1_std_fit = fitMeasures(sd_cfa_1_std, output = "matrix",
                               fit.measures = c("cfi", "cfi.robust", "rmsea", "rmsea.robust", "srmr"))
write.csv(sd_cfa_1_std_fit, file = "cfa_1fac_std_fit_w.csv", row.names = TRUE)

# liberal democracy factor with orthogonal methods factor, ordinal

sd_cfa_1_std = cfa(cfa_mod_1, data=pt_dat, estimator="WLSMV", orthogonal=TRUE, ordered=TRUE, std.lv=TRUE)
summary(sd_cfa_1_std, fit.measures=TRUE)
semTable(sd_cfa_1_std, paramSets = c("fits", "loadings", "latentvariances", "latentcovariances"),
         fits=c("chisq", "cfi", "rmsea", "srmr"), columns=c("est", "se", "p"), 
         type="html", file="cfa_1fac_ord_std_table.html")
sd_cfa_1_std_fit = fitMeasures(sd_cfa_1_std,  output = "matrix",
                               fit.measures = c("cfi", "cfi.robust", "rmsea", "rmsea.robust", "srmr"))
write.csv(sd_cfa_1_std_fit, file = "cfa_1fac_std_ord_fit.csv", row.names = TRUE)

# electoral democracy and rule of laws factors with orthogonal methods factor

cfa_mod_2 = '
SupED =~ FREXP1 + FREXP2 + FRASSC1 + FRASSC2 + FRASSC3 + UNISUFF1 + UNISUFF2 
          + DECELEC1 + DECELEC2 + FRELECT1 + FRELECT2
SupRL =~  JUDCNSTR1 + JUDCNSTR2 + LEGCNSTR1 + LEGCNSTR2 + EQLAW1 + EQLAW2
PosVal =~ FREXP1 + FRASSC2 + UNISUFF2 + DECELEC2 + FRELECT1 + JUDCNSTR1 + LEGCNSTR2 + EQLAW2
PosVal ~~ 0*SupED
PosVal ~~ 0*SupRL
'
sd_cfa_2_std = cfa(cfa_mod_2, data=pt_dat, estimator="MLR", std.lv=TRUE,
                   sampling.weights="adj_wt")
semTable(sd_cfa_2_std, paramSets = c("fits", "loadings", "latentvariances", "latentcovariances"),
         fits=c("chisq", "cfi", "rmsea", "srmr"), columns=c("est", "se", "p"),
         type="html", file="cfa_2fac_std_table_w.html")
sd_cfa_2_std_fit = fitMeasures(sd_cfa_2_std, output = "matrix",
                               fit.measures = c("cfi", "cfi.robust", "rmsea", "rmsea.robust", "srmr"))
write.csv(sd_cfa_2_std_fit, file = "cfa_2fac_std_fit_w.csv", row.names = TRUE)

# electoral democracy and rule of laws factors with orthogonal methods factor

sd_cfa_2_std = cfa(cfa_mod_2, data=pt_dat, estimator="WLSMV", ordered=TRUE, std.lv=TRUE)
summary(sd_cfa_2_std, fit.measures=TRUE)
semTable(sd_cfa_2_std, paramSets = c("fits", "loadings", "latentvariances", "latentcovariances"),
         fits=c("chisq", "cfi", "rmsea", "srmr"), columns=c("est", "se", "p"), 
         type="html", file="cfa_2fac_ord_std_table.html")
sd_cfa_2_std_fit = fitMeasures(sd_cfa_2_std, output = "matrix",
                               fit.measures = c("cfi", "cfi.robust", "rmsea", "rmsea.robust", "srmr"))
write.csv(sd_cfa_2_std_fit, file = "cfa_2fac_std_ord_fit.csv", row.names = TRUE)

# lr test - 1 v 2-fac models

lavTestLRT(sd_cfa_1_std, sd_cfa_2_std, method = "satorra.bentler.2010")
write.csv(lavTestLRT(sd_cfa_2_std, sd_cfa_1_std, method = "satorra.bentler.2010"), 
          file = "lrtest_cfas.csv", row.names = TRUE)


## Trimmed 7-item scale

pt_dat_7 = pt_dat[, c("FREXP2", "FRASSC1", "UNISUFF1", "FRELECT2", "JUDCNSTR2", "LEGCNSTR1", "EQLAW1")]

# 1-factor CFA

cfa_mod_7i = 'SupLD =~ FREXP2 + FRASSC1 + UNISUFF1 + FRELECT2 + JUDCNSTR2 + LEGCNSTR1 + EQLAW1'

sd_cfa_7i_std = cfa(cfa_mod_7i, data=pt_dat, estimator="MLR", std.lv=TRUE,
                    sampling.weights="adj_wt")
summary(sd_cfa_7i_std, fit.measures=TRUE)
semTable(sd_cfa_7i_std, paramSets = c("fits", "loadings", "latentvariances", "latentcovariances"),
         fits=c("chisq", "cfi", "rmsea", "srmr"), columns=c("est", "se", "p"),
         type="html", file="cfa_7it_std_table_w.html")
sd_cfa_7i_fit = fitMeasures(sd_cfa_7i_std, output = "matrix",
                            fit.measures = c("cfi", "cfi.robust", "rmsea", "rmsea.robust", "srmr"))
write.csv(sd_cfa_7i_fit, file = "cfa_7it_std_fit_w.csv", row.names = TRUE)

# 1-factor CFA, ordinal

sd_cfa_7i_ord = cfa(cfa_mod_7i, data=pt_dat, estimator="WLSMV", ordered=TRUE, std.lv=TRUE)
summary(sd_cfa_7i_ord, fit.measures=TRUE)
semTable(sd_cfa_7i_ord, paramSets = c("fits", "loadings", "latentvariances", "latentcovariances"),
         fits=c("chisq", "cfi", "rmsea", "srmr"), columns=c("est", "se", "p"),
         type="html", file="cfa_7it_ord_std_table.html")
sd_cfa_7i_fit = fitMeasures(sd_cfa_7i_ord, output = "matrix",
                            fit.measures = c("cfi", "cfi.robust", "rmsea", "rmsea.robust", "srmr"))
write.csv(sd_cfa_7i_fit, file = "cfa_7it_ord_std_fit.csv", row.names = TRUE)

# eigenvalues of 7-item scale
sd7_cor = cor(pt_dat_7, use="pair")
eigen(sd7_cor)$values
write.csv(eigen(sd7_cor)$values, file="sd7_eigen.csv")

# reliability of 7-item scale
psych::alpha(sd7_cor)
alph7_out <- psych::alpha(sd7_cor)
write.csv(alph7_out[[1]], file="sd7_alpha.csv")
# ordinal reliability
sd7_pcor = polychoric(pt_dat_7)$rho
alph7_ord_out <- psych::alpha(sd7_pcor)
write.csv(alph7_ord_out[[1]], file="sd7_ord_alpha.csv")

# create additive 7-item scale
pt_dat$SUPDEM_7IT = rowMeans(pt_dat_7)


## Correlations with criterion variables

# select and recode variables

pt_dat$SUPDEM_7IT = pt_dat$SUPDEM_7IT

table(pt_dat$LR_IDEOL, useNA="ifany")
table(pt_dat$GOVT_APPROV, useNA="ifany")
table(pt_dat$SATIS_DEM, useNA="ifany")
table(pt_dat$IMPORT_DEMOC, useNA="ifany")
table(pt_dat$STRONG_LEAD, useNA="ifany")
table(pt_dat$POL_TRUST, useNA="ifany")

# create and save mixed correlation matrix

cor_items = c("SUPDEM_7IT", "STRONG_LEAD", "IMPORT_DEMOC", 
              "SATIS_DEM", "GOVT_APPROV", "LR_IDEOL", "POL_TRUST")
crit_cor = mixedCor(pt_dat[, cor_items])$rho
write.csv(crit_cor, file="sd7_crit_cormat.csv")
