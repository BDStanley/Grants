#### Measuring support for liberal democracy
#### Code for revised draft of paper
#### Version 5 - February 2024

library(tidyverse)
library(psych)
library(lavaan)
library(car)
library(semTable)
library(psychTools)
library(tth)
library(haven)
library(RColorBrewer)
library(matrixStats)
library(pewmethods)

sd_dat = read_dta("sd_dat.dta")

# examine responses
names(sd_dat)
summary(sd_dat)

# check if DKs and NAs are included and how they are coded
sapply(sd_dat, table, useNA="ifany") 

# select 17 sup dem items
sd_17 = sd_dat[, 4:20]

## Plot item distributions

## Plot the distributions as the items were asked and answered, i.e., don't recode DKs or reflect the response set
## Include the response categories in this order: strongly agree, agree, neither, disagree, strongly disagree, DK

# colour palettes 
lik5 = c(brewer.pal(5, "BrBG"))
lik5_labs = c("StrAg", "SomeAg", "Neither", "SomeDis", "StrDis")

sd_plot = sd_17

# plot
pdf("supdem_distr_germany.pdf", height=8, width=6)
par(mfrow=c(5, 4), mar=c(3, 2, 0.5, 0.5), tcl=-0.2, cex=0.9, las=2, mgp=c(1.8, 0.9, 0))
for(i in 1:length(sd_plot)) {
  barplot(height = table(sd_plot[, names(sd_plot)[i]]) / dim(sd_plot)[1] * 100, names.arg=lik5_labs, 
          axes=FALSE, col=lik5, cex.names=0.7, mgp=c(1, 0.2, 0), ylim=c(0, 80))
  axis(side=2, labels=TRUE, cex.axis=0.7, mgp=c(1, 0.4, 0))
  text(x=1.5, y=75, names(sd_plot)[i], cex=0.8, adj=0)
}
dev.off()


## Recode to orient all items in a pro-democratic direction and DKs as "neither"; 

sd_dat_r = sd_17
dem_vnam = c("FREXP1", "FRASSC2", "UNISUFF2", "DECELEC2", "FRELECT1", "JUDCNSTR1", "LEGCNSTR2", "EQLAW2")
aut_vnam = c("FREXP2", "FRASSC1", "FRASSC3", "UNISUFF1", "DECELEC1", "FRELECT2", "JUDCNSTR2", "LEGCNSTR1", "EQLAW1")
sd_dat_r[, dem_vnam] = lapply(sd_dat[, dem_vnam], car::Recode, "1=5; 2=4; 3=3; 4=2; 5=1; else=NA")
sd_dat_r[, aut_vnam] = lapply(sd_dat[, aut_vnam], car::Recode, "1=1; 2=2; 3=3; 4=4; 5=5; else=NA")
sd_dat[, dem_vnam] = sd_dat_r[, dem_vnam]
sd_dat[, aut_vnam] = sd_dat_r[, aut_vnam]


## Create weights

# turn relevant variables into factors
var_columns = c("GENDER", "EDUCATION", "REGION", "AGE")
sd_dat[var_columns] = lapply(sd_dat[var_columns], factor)
lapply(sd_dat[var_columns], table, useNA = "ifany")

# population data
pop_margins = list(
  tibble(GENDER = as.factor(c(0, 1)), Freq = c(48.2, 51.8)),
  tibble(EDUCATION = as.factor(c(0, 1, 2)), Freq = c(36.6, 29.0, 29.4)),
  tibble(REGION = as.factor(c(0, 1)), Freq = c(20.4, 79.6)),
  tibble(AGE = as.factor(c(0, 1, 2)), Freq = c(31.2, 44.2, 24.6))
)

# raking
survey_weights = rake_survey(
  .data = sd_dat,
  pop_margins = pop_margins,
  scale_to_n = TRUE
)

# trim
sd_dat$wt_new = survey_weights
sd_dat$wt_new = trim_weights(survey_weights)
sd_dat$wt_new = sd_dat$wt_new / mean(sd_dat$wt_new)
summary(sd_dat$wt_new)

sd_dat_w = sd_dat[complete.cases(sd_dat$wt_new), ]


## Reliability and dimensionality

# alpha
sd_cor = cor(sd_dat_r, use="pair")
psych::alpha(sd_cor)
alph_out <- psych::alpha(sd_cor)
write.csv(alph_out[[1]], file="sd_alpha.csv")

# eigenvalues of principal components
eigen(sd_cor)$values
write.csv(eigen(sd_cor)$values, file="sd_eigen.csv")

# 1-factor EFA
psych::fa(sd_dat_r, nfactors=1)
efa1 = psych::fa(sd_dat_r, nfactors=1)
efa_html = tth(fa2latex(efa1))
writeLines(efa_html, "sd_efa1.html")

# ordinal
sd_pcor = polychoric(sd_dat_r)$rho
write.csv(sd_pcor, "sd_pcormat.csv", row.names=TRUE)
psych::fa(sd_pcor, nfactors=1, n.obs=dim(sd_dat)[1])
efa_ord = psych::fa(sd_pcor, nfactors=1, n.obs=dim(sd_dat)[1])
efa_ord_html = tth(fa2latex(efa_ord))
writeLines(efa_ord_html, "sd_efa1_ord.html")


## CFA models

# liberal democracy factor with orthogonal methods factor

cfa_mod_1 = '
SupLD =~ FREXP1 + FREXP2 + FRASSC1 + FRASSC2 + FRASSC3 + UNISUFF1 + UNISUFF2 
          + DECELEC1 + DECELEC2 + FRELECT1 + FRELECT2 + JUDCNSTR1 + JUDCNSTR2 
          + LEGCNSTR1 + LEGCNSTR2 + EQLAW1 + EQLAW2
PosVal =~ FREXP1 + FRASSC2 + UNISUFF2 + DECELEC2 + FRELECT1 + JUDCNSTR1 + LEGCNSTR2 + EQLAW2
'
sd_cfa_1_std = cfa(cfa_mod_1, data=sd_dat_w, estimator="MLR", orthogonal=TRUE, std.lv=TRUE, 
                   sampling.weights="wt_new")
semTable(sd_cfa_1_std, paramSets = c("fits", "loadings", "latentvariances", "latentcovariances"),
         fits=c("chisq", "cfi", "rmsea", "srmr"), columns=c("est", "se", "p"),
         type="html", file="cfa_1fac_std_table_w.html")
sd_cfa_1_std_fit = fitMeasures(sd_cfa_1_std, output = "matrix",
                               fit.measures = c("cfi", "cfi.robust", "rmsea", "rmsea.robust", "srmr"))
write.csv(sd_cfa_1_std_fit, file = "cfa_1fac_std_fit_w.csv", row.names = TRUE)

# liberal democracy factor with orthogonal methods factor, ordinal

sd_cfa_1_std = cfa(cfa_mod_1, data=sd_dat_r, estimator="WLSMV", orthogonal=TRUE, ordered=TRUE, std.lv=TRUE)
summary(sd_cfa_1_std, fit.measures=TRUE)
semTable(sd_cfa_1_std, paramSets = c("fits", "loadings", "latentvariances", "latentcovariances"),
         fits=c("chisq", "cfi", "rmsea", "srmr"), columns=c("est", "se", "p"), 
         type="html", file="cfa_1fac_ord_std_table.html")
sd_cfa_1_std_fit = fitMeasures(sd_cfa_1_std,  output = "matrix",
                               fit.measures = c("cfi", "cfi.robust", "rmsea", "rmsea.robust", "srmr"))
write.csv(sd_cfa_1_std_fit, file = "cfa_1fac_std_ord_fit.csv", row.names = TRUE)

# electoral democracy and rule of laws factors with orthogonal methods factor

cfa_mod_2 = '
SupED =~ FREXP1 + FREXP2 + FRASSC1 + FRASSC2 + FRASSC3 + UNISUFF1 + UNISUFF2 
          + DECELEC1 + DECELEC2 + FRELECT1 + FRELECT2
SupRL =~  JUDCNSTR1 + JUDCNSTR2 + LEGCNSTR1 + LEGCNSTR2 + EQLAW1 + EQLAW2
PosVal =~ FREXP1 + FRASSC2 + UNISUFF2 + DECELEC2 + FRELECT1 + JUDCNSTR1 + LEGCNSTR2 + EQLAW2
PosVal ~~ 0*SupED
PosVal ~~ 0*SupRL
'
sd_cfa_2_std = cfa(cfa_mod_2, data=sd_dat_w, estimator="MLR", std.lv=TRUE, 
                   sampling.weights="wt_new")
semTable(sd_cfa_2_std, paramSets = c("fits", "loadings", "latentvariances", "latentcovariances"),
         fits=c("chisq", "cfi", "rmsea", "srmr"), columns=c("est", "se", "p"),
         type="html", file="cfa_2fac_std_table_w.html")
sd_cfa_2_std_fit = fitMeasures(sd_cfa_2_std, output = "matrix",
                               fit.measures = c("cfi", "cfi.robust", "rmsea", "rmsea.robust", "srmr"))
write.csv(sd_cfa_2_std_fit, file = "cfa_2fac_std_fit_w.csv", row.names = TRUE)

# electoral democracy and rule of laws factors with orthogonal methods factor

sd_cfa_2_std = cfa(cfa_mod_2, data=sd_dat_r, estimator="WLSMV", ordered=TRUE, std.lv=TRUE)
summary(sd_cfa_2_std, fit.measures=TRUE)
semTable(sd_cfa_2_std, paramSets = c("fits", "loadings", "latentvariances", "latentcovariances"),
         fits=c("chisq", "cfi", "rmsea", "srmr"), columns=c("est", "se", "p"), 
         type="html", file="cfa_2fac_ord_std_table.html")
sd_cfa_2_std_fit = fitMeasures(sd_cfa_2_std, output = "matrix",
                               fit.measures = c("cfi", "cfi.robust", "rmsea", "rmsea.robust", "srmr"))
write.csv(sd_cfa_2_std_fit, file = "cfa_2fac_std_ord_fit.csv", row.names = TRUE)

# lr test - 1 v 2-fac models

lavTestLRT(sd_cfa_1_std, sd_cfa_2_std, method = "satorra.bentler.2010")
write.csv(lavTestLRT(sd_cfa_2_std, sd_cfa_1_std, method = "satorra.bentler.2010"), 
          file = "lrtest_cfas.csv", row.names = TRUE)


## Trimmed 7-item scale

sd_dat_7 = sd_dat_r[, c("FREXP2", "FRASSC1", "UNISUFF1", "FRELECT2", "JUDCNSTR2", "LEGCNSTR1", "EQLAW1")]

# 1-factor CFA

cfa_mod_7i = 'SupLD =~ FREXP2 + FRASSC1 + UNISUFF1 + FRELECT2 + JUDCNSTR2 + LEGCNSTR1 + EQLAW1'

sd_cfa_7i_std = cfa(cfa_mod_7i, data=sd_dat_w, estimator="MLR", std.lv=TRUE, 
                    sampling.weights="wt_new")
summary(sd_cfa_7i_std, fit.measures=TRUE)
semTable(sd_cfa_7i_std, paramSets = c("fits", "loadings", "latentvariances", "latentcovariances"),
         fits=c("chisq", "cfi", "rmsea", "srmr"), columns=c("est", "se", "p"),
         type="html", file="cfa_7it_std_table_w.html")
sd_cfa_7i_fit = fitMeasures(sd_cfa_7i_std, output = "matrix",
                            fit.measures = c("cfi", "cfi.robust", "rmsea", "rmsea.robust", "srmr"))
write.csv(sd_cfa_7i_fit, file = "cfa_7it_std_fit_w.csv", row.names = TRUE)

# 1-factor CFA, ordinal

sd_cfa_7i_ord = cfa(cfa_mod_7i, data=sd_dat_r, estimator="WLSMV", ordered=TRUE, std.lv=TRUE)
summary(sd_cfa_7i_ord, fit.measures=TRUE)
semTable(sd_cfa_7i_ord, paramSets = c("fits", "loadings", "latentvariances", "latentcovariances"),
         fits=c("chisq", "cfi", "rmsea", "srmr"), columns=c("est", "se", "p"),
         type="html", file="cfa_7it_ord_std_table.html")
sd_cfa_7i_fit = fitMeasures(sd_cfa_7i_ord, output = "matrix",
                            fit.measures = c("cfi", "cfi.robust", "rmsea", "rmsea.robust", "srmr"))
write.csv(sd_cfa_7i_fit, file = "cfa_7it_ord_std_fit.csv", row.names = TRUE)

# eigenvalues of 7-item scale
sd7_cor = cor(sd_dat_7, use="pair")
eigen(sd7_cor)$values
write.csv(eigen(sd7_cor)$values, file="sd7_eigen.csv")

# reliability of 7-item scale
psych::alpha(sd7_cor)
alph7_out <- psych::alpha(sd7_cor)
write.csv(alph7_out[[1]], file="sd7_alpha.csv")

# ordinal reliability
sd7_pcor = polychoric(sd_dat_7)$rho
alph7_ord_out <- psych::alpha(sd7_pcor)
write.csv(alph7_ord_out[[1]], file="sd7_ord_alpha.csv")

# create additive 7-item scale
sd_dat$SUPDEM_7IT = rowMeans(sd_dat_7)


## Correlations with criterion variables

# create and save mixed correlation matrix

cor_items = c("SUPDEM_7IT", "STRONG_LEAD", "IMPORT_DEMOC", 
              "SATIS_DEM", "GOVT_APPROV", "LR_IDEOL", "POL_TRUST")
crit_cor = mixedCor(sd_dat[, cor_items])$rho
write.csv(crit_cor, file="sd7_crit_cormat.csv")
