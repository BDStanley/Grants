This folder provides the code and data to replicate the analyses in "Conceptualizing and Measuring Support for Democracy: A New Approach", by Claassen et al.

Start by running this file: 1_supdem_within_cntry_analysis.R

It runs the analysis within each sample. The data and code for each sample are found in the folder named after the respective country. 

If you have any issues with this file, you can run the code separately for each sample.

Then run this file: 2_supdem_cross_cntry_analysis.R

It pulls results from the separate sample analyses and creates the tables and figures used in the paper. This code requires that the folder structure remain unchanged.


R session information: 

R version 4.3.1 (2023-06-16 ucrt)
Platform: x86_64-w64-mingw32/x64 (64-bit)
Running under: Windows 11 x64 (build 22631)

Matrix products: default


locale:
[1] LC_COLLATE=English_United Kingdom.utf8  LC_CTYPE=English_United Kingdom.utf8    LC_MONETARY=English_United Kingdom.utf8
[4] LC_NUMERIC=C                            LC_TIME=English_United Kingdom.utf8    

time zone: Europe/London
tzcode source: internal

attached base packages:
[1] stats     graphics  grDevices utils     datasets  methods   base     

other attached packages:
 [1] rstudioapi_0.14    pewmethods_1.0     semTable_1.8       labelled_2.11.0    XML_3.99-0.14      colorspace_2.1-0  
 [7] countrycode_1.5.0  pals_1.7           reshape2_1.4.4     lme4_1.1-33        Matrix_1.5-4.1     matrixStats_0.63.0
[13] RColorBrewer_1.1-3 haven_2.5.3        tth_4.12-0-1       psychTools_2.3.3   car_3.1-2          carData_3.0-5     
[19] lavaan_0.6-16      psych_2.3.9        lubridate_1.9.3    forcats_1.0.0      stringr_1.5.0      dplyr_1.1.2       
[25] purrr_1.0.1        readr_2.1.4        tidyr_1.3.0        tibble_3.2.1       ggplot2_3.4.2      tidyverse_2.0.0   

loaded via a namespace (and not attached):
  [1] libcoin_1.0-10       tensorA_0.36.2       shape_1.4.6          magrittr_2.0.3       TH.data_1.1-2       
  [6] jomo_2.7-6           modeltools_0.2-23    rmarkdown_2.21       farver_2.1.1         nloptr_2.0.3        
 [11] vctrs_0.6.2          minqa_1.2.5          htmltools_0.5.5      distributional_0.3.2 survey_4.2-1        
 [16] broom_1.0.4          cellranger_1.1.0     Formula_1.2-5        mitml_0.4-5          plyr_1.8.8          
 [21] sandwich_3.0-2       rootSolve_1.8.2.4    zoo_1.8-12           lifecycle_1.0.3      iterators_1.0.14    
 [26] pkgconfig_2.0.3      fastmap_1.1.1        R6_2.5.1             rbibutils_2.2.13     collapse_1.9.5      
 [31] digest_0.6.31        Exact_3.2            miscTools_0.6-26     ps_1.7.5             fansi_1.0.4         
 [36] timechange_0.2.0     httr_1.4.5           abind_1.4-5          compiler_4.3.1       proxy_0.4-27        
 [41] withr_2.5.0          backports_1.4.1      DBI_1.1.3            maps_3.4.1           pan_1.9             
 [46] MASS_7.3-60          rcompanion_2.4.34    gld_2.6.6            tools_4.3.1          pbivnorm_0.6.0      
 [51] ranger_0.16.0        foreign_0.8-84       lmtest_0.9-40        zip_2.3.0            nnet_7.3-19         
 [56] glue_1.6.2           quadprog_1.5-8       nlme_3.1-162         grid_4.3.1           cmdstanr_0.6.1      
 [61] checkmate_2.1.0      generics_0.1.3       gtable_0.3.3         nortest_1.0-4        tzdb_0.4.0          
 [66] class_7.3-22         data.table_1.14.8    lmom_3.0             hms_1.1.3            coin_1.4-3          
 [71] utf8_1.2.3           foreach_1.5.2        pillar_1.9.0         posterior_1.4.1      mitools_2.4         
 [76] splines_4.3.1        lattice_0.21-8       survival_3.5-5       kutils_1.70          tidyselect_1.2.0    
 [81] knitr_1.42           plm_2.6-3            stats4_4.3.1         xfun_0.39            expm_0.999-7        
 [86] stringi_1.7.12       boot_1.3-28.1        evaluate_0.20        codetools_0.2-19     multcompView_0.1-9  
 [91] cli_3.6.1            rpart_4.1.19         xtable_1.8-4         DescTools_0.99.50    Rdpack_2.4          
 [96] munsell_0.5.0        processx_3.8.1       dichromat_2.0-0.1    Rcpp_1.0.11          readxl_1.4.2        
[101] mapproj_1.2.11       bdsmatrix_1.3-6      parallel_4.3.1       bayesplot_1.10.0     glmnet_4.1-8        
[106] mvtnorm_1.1-3        stationery_1.0       scales_1.2.1         e1071_1.7-13         openxlsx_4.2.5.2    
[111] maxLik_1.5-2         rlang_1.1.0          multcomp_1.4-25      mnormt_2.1.1         mice_3.16.0         
> 